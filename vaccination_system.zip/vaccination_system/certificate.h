#ifndef __certificate
#define __certificate

using namespace std;
class certificate
{

    public:
    certificate();

    void print(string,char,long long,string,int ,string, string,int ,int,int,int,int);

};

#endif