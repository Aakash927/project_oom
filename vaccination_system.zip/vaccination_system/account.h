#ifndef __account
#define __account

# include "reg.h"

class account
{
    public:
    long long int phno;

    public:
    account();

    account(long long int);

    

    reg r;

};

#endif