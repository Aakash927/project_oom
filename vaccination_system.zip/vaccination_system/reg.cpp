using namespace std;

# include "reg.h"

reg::reg(){}      


void reg::setdetails(string n,int a,string g)
    {
        name = n;
        age = a;
        gender = g;
    }


