#ifndef __slot
#define __slot

class slot
{
    public:
    char c;
    int dd,mm,yy;
    int hh,min;

    public:

    slot();
    
    void getslot();

};


#endif
