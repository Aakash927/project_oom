# include <iostream>
using namespace std;

# include "vaccine.h"

vaccine::vaccine(){}

void vaccine::display()
{
        cout<<vname<<endl;
}