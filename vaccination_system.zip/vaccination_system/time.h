bool isValidTime(int h,int m)
{
    if(h>=0 && h<=23 && m>=0 && m<=59)
    return true;
    else
    return false; 
}