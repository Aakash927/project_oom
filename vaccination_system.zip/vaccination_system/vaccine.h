#ifndef __vaccine
#define __vaccine

# include <string>
using namespace std;
class vaccine
{
    public:
    string vname;

    public:
    vaccine();

    virtual void display();
};

#endif