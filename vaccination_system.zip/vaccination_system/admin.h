#ifndef __admin
#define __admin

class admin
{
    public:
    void access();
};

#endif